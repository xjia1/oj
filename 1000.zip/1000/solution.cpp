#include <iostream>
#include <cstdio>
using namespace std;


//Author yixi

int main()
{
	int a, b;
	scanf("%d%d",&a,&b);
	printf("%d\n",a+b);
	return 0;
}
